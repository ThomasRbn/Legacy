package generator;

public class Constantes {
    /**
     * Tableau des pays possibles (10 pays)
     */
    public static final String[] PAYS = {"France", "Angleterre", "Ecosse", "Irlande", "Pays de Galles", "Italie", "Afrique du Sud", "Argentine", "Australie", "Nouvelle-Zélande"};
    /**
     * Tableau des id des équipes (10 équipes) dans le même ordre que le tableau des pays
     */
    public static final String[] IDEQUIPES = {"FRA", "ENG", "SCO", "IRL", "WAL", "ITA", "RSA", "ARG", "AUS", "NZL"};
    /**
     * Tableau des entraineurs (10 entraineurs) dans le même ordre que le tableau des pays
     */
    public static final String[] ENTRAINEURS = {"Jacques Brunel", "Eddie Jones", "Gregor Townsend", "Joe Schmidt", "Warren Gatland", "Conor O'Shea", "Rassie Erasmus", "Mario Ledesma", "Michael Cheika", "Steve Hansen"};
    /**
     * Tableau des stades (10 stades)
     */
    public static final String[] STADES = {"Stade de France", "Stade de Twickenham", "Murrayfield", "Stade Aviva", "Millennium Stadium", "Stade Olympique", "Ellis Park Stadium", "Estadio Malvinas Argentinas", "ANZ Stadium", "Eden Park"};
    /**
     * Tableau des villes (10 villes) dans le même ordre que le tableau des stades
     */
    public static final String[] VILLES = {"Saint-Denis", "Londres", "Edimbourg", "Dublin", "Cardiff", "Rome", "Johannesburg", "Mendoza", "Sydney", "Auckland"};

    /**
     * Tableau des couleurs (10 couleurs)
     */
    public static final String[] COULEURS = {"Rouge", "Vert", "Bleu", "Jaune", "Orange", "Violet", "Mauve", "Rose", "Noir", "Blanc"};
    /**
     * Tableau des postes (10 postes)
     */
    public static final String[] POSTES = {"Pilier", "Talonneur", "Deuxième ligne", "Troisième ligne aile", "Troisième ligne centre", "Demi de mêlée", "Demi d'ouverture", "Ailier", "Centre", "Arrière"};

    /**
     * Tableau des arbitres (10 arbitres)
     */
    public static final String[] ARBITRES = {
            "Jacques Peyper", "Romain Poite", "Luke Pearce", "Ben O'Keeffe", "Glen Jackson", "Angus Gardner", "John Lacey", "Mike Adamson", "Andrew Brace", "Paul Williams"
    };

    /**
     * Tableau des noms des joueurs de l'équipe de France
     */
    public static final String[] JOUEURS_FRA = {
            "Antoine Dupont", "Gaëtan Jaminet", "Gaël Fickou", "Virimi Villiéron", "Peato Mauvaka", "Charles Ollivon", "Julien Marchand", "Anthony Alldritt", "Joe Taofifenua", "Cameron Woki",
            "Damian Lebel", "Louis Le Roux", "Pierre-Louis Cretin", "Paul Pithon", "Mathieu Moefana",
            "Gaël Ramos", "Rémy Barlot", "Anthony Taofifenua", "Anthony Macalou", "Baptiste Jalibert", "Paul Iribaren", "Dorian Gros", "Ramos Tolotu", "Charles Ramos", "Charles Danty"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Angleterre
     */
    public static final String[] JOUEURS_ENG = {
            "Ellis Genge", "Jamie George", "Will Stuart", "Maro Itoje", "Charlie Ewels", "Courtney Lawes", "Tom Curry", "Sam Underhill", "Jack Willis", "Billy Vunipola",
            "Owen Farrell", "Marcus Smith", "Elliot Daly", "Henry Arundell", "Joe Cokanasiga",
            "Bevan Rodd", "Theo Dan", "Kyle Sinckler", "David Ribbans", "George Martin", "Lewis Ludlam", "Jack Willis", "Billy Vunipola", "Marcus Smith", "Henry Arundell", "Joe Cokanasiga", "Jonny May", "Jack Nowell"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Ecosse
     */
    public static final String[] JOUEURS_ECO = {
            "Hamish Watson", "Jamie Ritchie", "Duhan van der Merwe", "Chris Harris", "Mark Bennett", "Finn Russell", "George Turner", "Sam Skinner", "Grant Gilchrist", "Scott Cummings",
            "Ali Price", "Blair Kinghorn", "Rory Hutchinson", "Andy Christie", "Ewan Ashman",
            "Pierre Schoeman", "George Horne", "Jamie Bhatti", "Callum Hunter-Hill", "Robbie Henshaw", "Sam Hidalgo-Clyne", "Dorian Johnson", "Matt Fagerson", "Cameron Redpath", "Ross Thompson", "Rufus McLean", "Rory Darge", "Jamie Hodgson"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Irlande
     */
    public static final String[] JOUEURS_IRL = {
            "Andrew Porter", "Ronan Kelleher", "Tadhg Furlong", "James Ryan", "Peter O'Mahony", "Josh van der Flier", "Caelan Doris", "Jamison Gibson-Park", "Jonathan Sexton", "Bundee Aki",
            "Robbie Henshaw", "Hugo Keenan", "James Lowe", "Garry Ringrose", "Conor Murray",
            "Dave Heffernan", "Finlay Bealham", "Tadhg Beirne", "Ryan Baird", "Jack Conan", "Cian Healy", "Joey Carbery", "Keith Earls", "Jordan Larmour", "Michael Lowry", "Dan Sheehan", "Kieran Treadwell", "Mack Hansen", "Ultan Dillane"
    };


    /**
     * Tableau des noms des joueurs de l'équipe du Pays de Galles
     */
    public static final String[] JOUEURS_WAL = {
            "Wyn Jones", "Ryan Elias", "Tomas Francis", "Adam Beard", "Alun Wyn Jones", "Oli Moriarty", "Taulupe Faletau", "Kieran Hardy", "Gareth Anscombe", "George North",
            "Josh Adams", "Alex Cuthbert", "Louis Rees-Zammit", "Liam Williams", "Nick Tompkins",
            "Sam Parry", "Dillon Lewis", "Will Rowlands", "Josh Navidi", "Ross Moriarty", "Jonathan Davies", "Rhys Patchell", "Liam Williams", "Owen Watkin", "Jonathan Davies", "Rhys Carre", "Rhys Davies", "Tom Prydie", "Taine Basham", "Willis Halaholo"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Italie
     */
    public static final String[] JOUEURS_ITA = {
            "Michele Lamaro", "Federico Ruzza", "Niccolò Cannone", "Gianmarco Lucchesi", "Cosimo Angelini", "Michele Azzalino", "Tommaso Menoncello", "Stephen Varney", "Paolo Garbisi", "Tommaso Allan",
            "Federico Mori", "Monty Ioane", "Tommaso D'Allessandro", "Ange Capuozzo", "Luca Morisi",
            "Pietro Ceccarelli", "Ivan Nemer", "Giovanni Pettinelli", "Marco Fuser", "Guglielmo Palazzani", "Renato Giammarioli", "Giuseppe Berchesi", "Carlo Canna", "Marco Zanon", "Ludovico Cannone", "Davide Garbisi", "Edoardo Padovani", "Pierre Bruno", "Manuel Zuliani", "Matteo Nocera"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Afrique du Sud
     */
    public static final String[] JOUEURS_RSA = {
            "Eben Etzebeth", "Lood de Jager", "Franco Mostert", "Marcell Coetzee", "Pieter-Steph du Toit", "Kwagga Smith", "Jasper Wiese", "Faf de Klerk", "Handré Pollard", "Damian de Allende",
            "Makazole Mapimpi", "Willie le Roux", "Lukhanyo Am", "Embrose Papier", "Courtnall Skosan",
            "Trevor Nyakane", "Vincent Koch", "Frans Malherbe", "Steven Kitshoff", "Ox Nche", "Elrigh Louw", "Denzel du Plessis", "Garrick Marx", "Hacjivah Dayimani", "Ruan Nortje", "Jesse Kriel", "Elton Jantjies", "Morné Steyn", "Damian Willemse", "Warrick Gelant", "Thando Ntini"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Argentine
     */
    public static final String[] JOUEURS_ARG = {
            "Emiliano Boffelli", "Juan Cruz Mallía", "Matías Moroni", "Jerónimo de la Fuente", "Santiago Carreras", "Tomás Cubelli", "Marcos Kremer", "Juan Martín González", "Guido Petti Pagadizabal", "Germán Lanza",
            "Matías Alemanno", "Francisco Gómez Kodela", "Rodrigo Isgró", "Julián Montoya", "Nahuel Tetaz Chaparro",
            "Thomas Gallo", "Agustín Creevy", "Joel Sclavi", "Matías Matera", "Santiago Grondona", "Joaquín Oviedo", "Mayco Vivas", "Nicolás Sánchez", "Santiago Cordero", "Matías Orlando", "Pedro Rubiolo", "Tomás Albornoz", "Bautista Delguy"
    };

    /**
     * Tableau des noms des joueurs de l'équipe d'Australie
     */
    public static final String[] JOUEURS_AUS = {
            "Angus Bell", "David Porecki (c)", "James Slipper", "Nick Frost", "Richard Arnold", "Robert Leota", "Tom Hooper", "Rob Valetini",
            "Samu Kerevi", "Noah Lolesio",
            "Marika Koroibete", "Andrew Kellaway", "Tom Wright", "Hunter Paisami", "Jordan Petaia",
            "Dave Heffernan", "Finlay Bealham", "Tadhg Beirne", "Ryan Baird", "Jack Conan", "Cian Healy", "Joey Carbery", "Keith Earls", "Jordan Larmour", "James Lowe", "Michael Lowry", "Dan Sheehan", "Kieran Treadwell", "Mack Hansen", "Ultan Dillane"
    };

    /**
     * Tableau des noms des joueurs de l'équipe de Nouvelle-Zélande
     */
    public static final String[] JOUEURS_NZL = {
            "Codie Taylor", "Samisoni Taukei'aho", "Ofa Tuungafasi", "Brodie Retallick", "Sam Whitelock", "Scott Barrett", "Ardie Savea", "Sam Cane", "Tawera Kerr-Barlow", "Richie Mo'unga",
            "Rieko Ioane", "Bundee Aki", "Anton Lienert-Brown", "James Lowe", "Garry Ringrose",
            "Dalton Papalii", "Luke Jacobson", "Tupou Vaa'i", "Hoskins Sotutu", "Ethan Blackadder", "Caleb Clarke", "Will Jordan", "David Havili", "Jordie Barrett", "Braydon Ennor", "Josh Ioane", "Finlay Christie", "Ethan de Groot", "Marcell Coetzee", "Brad Weber", "Isaia Walker-Leawere"
    };
}
