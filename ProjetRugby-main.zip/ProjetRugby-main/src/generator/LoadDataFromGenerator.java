package generator;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import entity.Match;
import org.bson.codecs.configuration.CodecProvider;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import java.text.ParseException;

import static com.mongodb.MongoClientSettings.getDefaultCodecRegistry;
import static com.mongodb.client.model.Filters.eq;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

public class LoadDataFromGenerator {

    public static void main(String[] args) throws ParseException {
        CodecProvider pojoCodecProvider = PojoCodecProvider.builder().automatic(true).build();
        CodecRegistry pojoCodecRegistry = fromRegistries(getDefaultCodecRegistry(), fromProviders(pojoCodecProvider));

        System.out.println(pojoCodecRegistry);
        System.out.println(pojoCodecProvider);
        //Connexion à la base de données
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("toto").withCodecRegistry(pojoCodecRegistry);
        database.drop();
        System.out.println("Database created successfully");

        //Creation de la collection
        MongoCollection<Match> matchs = database.getCollection("matchs", Match.class);

        //Insertion des documents
        for (int matchIndex = 1; matchIndex <= 50; matchIndex++) {
            matchs.insertOne(Generateur.genererMatch(matchIndex));
        }

        //On vérifie que chaque équipe ait au moins un match
        for (String idEquipe : Constantes.IDEQUIPES) {
            if (matchs.countDocuments(eq("equipeD.idEquipe", idEquipe)) == 0 && matchs.countDocuments(eq("equipeE.idEquipe", idEquipe)) == 0) {
                throw new RuntimeException("L'équipe " + idEquipe + " n'a pas de match");
            }
        }

        System.out.println("Collection created and populated successfully");
    }
}
