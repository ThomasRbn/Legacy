package generator;

import entity.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

public class Generateur {


    /**
     * Génère un arbitre à partir de son nom et de son id
     *
     * @param indiceArbitre Id de l'arbitre
     * @return Arbitre
     */
    public static Arbitre genererArbitre(int indiceArbitre) {
        Arbitre arbitre = new Arbitre();
        arbitre.setIdArbitre("AR_" + indiceArbitre); // Ex: "AR_1" ou "AR_14
        arbitre.setPrenom(Constantes.ARBITRES[indiceArbitre].split(" ", 2)[0]);
        arbitre.setNom(Constantes.ARBITRES[indiceArbitre].split(" ", 2)[1]);

        arbitre.setNationalite(Constantes.PAYS[indiceArbitre]);
        return arbitre;
    }

    /**
     * Génère une équipe aléatoire, qui n'est pas l'équipe adverse
     *
     * @param idEquipeAdverse Id de l'équipe adverse, null si pas encore d'équipe adverse
     * @return Equipe
     */
    public static Equipe genererEquipe(String idEquipeAdverse) {
        Equipe equipe = new Equipe();
        Random random = new Random();

        //On choisi une équipe aléatoirement
        int indexTeam = random.nextInt(Constantes.IDEQUIPES.length);

        //Si une équipe adverse est déjà définie, on vérifie que l'équipe choisie n'est pas la même
        if (idEquipeAdverse != null) {
            while (Constantes.IDEQUIPES[indexTeam].equals(idEquipeAdverse)) {
                indexTeam = random.nextInt(Constantes.IDEQUIPES.length);
            }
        }

        //On définit les attributs de l'équipe, toujours le même pour un même pays, quelque soit le match
        equipe.setIdEquipe(Constantes.IDEQUIPES[indexTeam]);
        equipe.setPays(Constantes.PAYS[indexTeam]);
        equipe.setCouleur(Constantes.COULEURS[indexTeam]);
        equipe.setEntraineur(Constantes.ENTRAINEURS[indexTeam]);
        return equipe;
    }

    /**
     * Génère un joueur aléatoire
     *
     * @param idEquipe  Id de l'équipe
     * @param titulaire Titulaire ou non
     * @param nom       Nom du joueur
     * @param idJoueur  Id du joueur
     * @return Joueur
     */
    public static Joueur genererJoueur(String idEquipe, boolean titulaire, String nom, int idJoueur) {
        Joueur joueur = new Joueur();
        Random random = new Random();

        joueur.setIdEquipe(idEquipe); // Ex: "FRA" ou "NZL"
        joueur.setIdJoueur(idEquipe + "_" + idJoueur); // Ex: "FRA_1" ou "NZL_14
        joueur.setPrenom(nom.split(" ", 2)[0]);
        joueur.setNom(nom.split(" ", 2)[1]);

        //Sélection du poste
        int indexPoste = random.nextInt(Constantes.POSTES.length);
        joueur.setPoste(genererPoste(indexPoste));

        //On définit les attributs du joueur
        //On estime qu'un joueur ne marque pas plus de 6 pts à lui tout seul par match
        joueur.setTitulaire(titulaire);
        joueur.setTempsJeu(random.nextInt(1, 80));
        joueur.setPtsMarques(random.nextInt(7));

        //Si le joueur a marqué au moins 5 pts, il y a une chance sur 2 qu'il ait marqué ces 5 pts via un essai
        if (joueur.getPtsMarques() >= 5) {
            joueur.setNbEssaisMarques(random.nextInt(0, 2));
        } else { //S'il a marqué moins de 5 pts, alors il n'a pas marqué d'essai
            joueur.setNbEssaisMarques(0);
        }

        //On calcule le coefficient d'efficacité du joueur
        joueur.setCoefficientEfficacite((double) joueur.getPtsMarques() / joueur.getTempsJeu());
        return joueur;
    }

    /**
     * Génère un poste aléatoire
     *
     * @param idPoste Id du poste
     * @return Poste
     */
    public static Poste genererPoste(int idPoste) {
        Poste poste = new Poste();
        poste.setIdPoste("PO_" + idPoste);
        poste.setLibelle(Constantes.POSTES[idPoste]);
        return poste;
    }

    /**
     * Génère un stade aléatoire
     *
     * @return Stade
     */
    public static Stade genererStade() {
        Stade stade = new Stade();
        Random random = new Random();

        //On choisi un stade aléatoirement
        int indexStade = random.nextInt(Constantes.STADES.length);
        stade.setIdStade("ST_" + indexStade); // Ex: "ST_1" ou "ST_14
        stade.setNom(Constantes.STADES[indexStade]);
        stade.setVille(Constantes.VILLES[indexStade]);
        stade.setCapacite(random.nextInt(10000, 100000)); //On estime qu'un stade a entre 10 000 et 100 000 places
        return stade;
    }

    /**
     * Génère un match aléatoire
     *
     * @param idMatch Id du match
     * @return Match
     */
    public static Match genererMatch(int idMatch) throws ParseException {
        Match match = new Match();
        Random random = new Random();

        match.setIdMatch(idMatch);
        match.setEquipeD(genererEquipe(null));
        match.setEquipeE(genererEquipe(match.getEquipeD().getIdEquipe()));
        match.setStade(genererStade());

        //On génère un arbitre aléatoire en faisant en sorte qu'il ne soit pas de la même nationalité que les équipes qui participent au match
        //Par souci de cohérence des données, on utilise le même index aléatoire pour choisir son nom, son id et sa nationalité
        int indexArbitre = new Random().nextInt(Constantes.ARBITRES.length);
        while (Constantes.PAYS[indexArbitre].equals(match.getEquipeD().getPays()) || Constantes.PAYS[indexArbitre].equals(match.getEquipeE().getPays())) {
            indexArbitre = new Random().nextInt(Constantes.ARBITRES.length);
        }
        match.setArbitre(genererArbitre(indexArbitre));

        //On génère une date aléatoire entre le 1er janvier 2020 et le 31 décembre 2022
        int day = random.nextInt(28);
        int month = random.nextInt(13);
        int year = random.nextInt(2020, 2023);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'00:00:00");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = sdf.parse(year + "-" + month + "-" + day + "T00:00:00");
        match.setDate(date);

        //On sélectionne la liste des joueurs de chaque équipe
        String[] joueursD = switch (match.getEquipeD().getPays()) {
            case "France" -> Constantes.JOUEURS_FRA;
            case "Angleterre" -> Constantes.JOUEURS_ENG;
            case "Ecosse" -> Constantes.JOUEURS_ECO;
            case "Irlande" -> Constantes.JOUEURS_IRL;
            case "Pays de Galles" -> Constantes.JOUEURS_WAL;
            case "Italie" -> Constantes.JOUEURS_ITA;
            case "Afrique du Sud" -> Constantes.JOUEURS_RSA;
            case "Argentine" -> Constantes.JOUEURS_ARG;
            case "Australie" -> Constantes.JOUEURS_AUS;
            case "Nouvelle-Zélande" -> Constantes.JOUEURS_NZL;
            default -> throw new IllegalStateException("Unexpected value: " + match.getEquipeD().getPays());
        };

        String[] joueursE = switch (match.getEquipeE().getPays()) {
            case "France" -> Constantes.JOUEURS_FRA;
            case "Angleterre" -> Constantes.JOUEURS_ENG;
            case "Ecosse" -> Constantes.JOUEURS_ECO;
            case "Irlande" -> Constantes.JOUEURS_IRL;
            case "Pays de Galles" -> Constantes.JOUEURS_WAL;
            case "Italie" -> Constantes.JOUEURS_ITA;
            case "Afrique du Sud" -> Constantes.JOUEURS_RSA;
            case "Argentine" -> Constantes.JOUEURS_ARG;
            case "Australie" -> Constantes.JOUEURS_AUS;
            case "Nouvelle-Zélande" -> Constantes.JOUEURS_NZL;
            default -> throw new IllegalStateException("Unexpected value: " + match.getEquipeE().getPays());
        };

        //On génère les 15 titulaires de chaque équipe
        ArrayList<Joueur> joueurs = new ArrayList<>();
        ArrayList<Integer> indexEquipeD = new ArrayList<>();
        ArrayList<Integer> indexEquipeE = new ArrayList<>();
        for (int i = 0; i < 15; i++) {
            int indexD = random.nextInt(joueursD.length);
            while (indexEquipeD.contains(indexD)) {
                indexD = random.nextInt(joueursD.length);
            }
            indexEquipeD.add(indexD);
            joueurs.add(genererJoueur(match.getEquipeD().getIdEquipe(), true, joueursD[indexD], indexD));
        }

        for (int i = 0; i < 15; i++) {
            int indexE = random.nextInt(joueursE.length);
            while (indexEquipeE.contains(indexE)) {
                indexE = random.nextInt(joueursE.length);
            }
            indexEquipeE.add(indexE);
            joueurs.add(genererJoueur(match.getEquipeE().getIdEquipe(), true, joueursE[indexE], indexE));
        }

        //On génère aléatoirement un nombre de remplaçants pour chaque équipe (entre 0 et 5)
        int nbRemplacantsD = random.nextInt(6);
        for (int i = 0; i < nbRemplacantsD; i++) {
            int indexD = random.nextInt(joueursD.length);
            while (indexEquipeD.contains(indexD)) {
                indexD = random.nextInt(joueursD.length);
            }
            indexEquipeD.add(indexD);
            joueurs.add(genererJoueur(match.getEquipeD().getIdEquipe(), false, joueursD[indexD], indexD));
        }

        int nbRemplacantsE = random.nextInt(4);
        for (int i = 0; i < nbRemplacantsE; i++) {
            int indexE = random.nextInt(joueursE.length);
            while (indexEquipeE.contains(indexE)) {
                indexE = random.nextInt(joueursE.length);
            }
            indexEquipeE.add(indexE);
            joueurs.add(genererJoueur(match.getEquipeE().getIdEquipe(), false, joueursE[i + 15], i + 15));
        }

        //On ajoute les joueurs (titulaires et remplacants) au match
        match.setJoueurs(joueurs);

        //On compte le nombre de points et d'essais marqués par chaque équipe
        int ptsD = 0;
        int ptsE = 0;
        int essaisD = 0;
        int essaisE = 0;
        for (Joueur joueur : match.getJoueurs()) { // On parcourt tous les joueurs du match pour compter les points et les essais
            if (joueur.getIdEquipe().equals(match.getEquipeD().getIdEquipe())) {
                ptsD += joueur.getPtsMarques();
                essaisD += joueur.getNbEssaisMarques();
            } else {
                ptsE += joueur.getPtsMarques();
                essaisE += joueur.getNbEssaisMarques();
            }
        }
        match.setPtsD(ptsD);
        match.setPtsE(ptsE);
        match.setEssaisD(essaisD);
        match.setEssaisE(essaisE);

        //On génère un nombre aléatoire de spectateurs (entre 10% et 100% de la capacité du stade associé)
        match.setNbSpecs(random.nextInt(match.getStade().getCapacite() / 10, match.getStade().getCapacite()));

        return match;
    }
}

