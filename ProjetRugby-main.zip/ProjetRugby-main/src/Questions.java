import com.mongodb.client.*;
import entity.Arbitre;
import entity.Joueur;
import entity.Match;
import generator.Constantes;
import org.bson.codecs.configuration.CodecProvider;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.mongodb.MongoClientSettings.getDefaultCodecRegistry;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Updates.set;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

public class Questions {

    /**
     * Afficher pour tous les joueurs de l'équipe E : leur temps de jeu,
     * le nombre d'essais marqués, le nombre de points marqués,
     * et le coefficient (nombre de points/durée de jeu).
     * On classera les joueurs par ordre décroissant du coefficient.
     * <p>
     * La question prend en compte les statistiques de tous les matchs de l'équipe et non pas par match.
     *
     * @param collection collections de collection
     */
    public static void questionA(MongoCollection<Match> collection, String idEquipe) {
        //TODO Sur tous les matchs ou par match ?
        Bson bsonQuery = or(eq("equipeD.idEquipe", idEquipe), eq("equipeE.idEquipe", idEquipe));
        FindIterable<Match> matches = collection.find(bsonQuery);

        HashMap<Joueur, HashMap<String, Number>> joueurs = new HashMap<>();

        for (Match match : matches) {
            for (Joueur joueur : match.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipe)) {
                    HashMap<String, Number> stats;
                    if (!joueurs.containsKey(joueur)) {
                        stats = new HashMap<>();
                        stats.put("tempsDeJeu", joueur.getTempsJeu());
                        stats.put("nbEssaisMarques", joueur.getNbEssaisMarques());
                        stats.put("ptsMarques", joueur.getPtsMarques());
                        stats.put("coefficient", joueur.getCoefficientEfficacite());
                    } else {
                        stats = joueurs.get(joueur);
                        stats.put("tempsDeJeu", (int) stats.get("tempsDeJeu") + joueur.getTempsJeu());
                        stats.put("nbEssaisMarques", (int) stats.get("nbEssaisMarques") + joueur.getNbEssaisMarques());
                        stats.put("ptsMarques", (int) stats.get("ptsMarques") + joueur.getPtsMarques());
                        stats.put("coefficient", (double) stats.get("coefficient") + joueur.getCoefficientEfficacite());
                    }
                    joueurs.put(joueur, stats);
                }
            }
        }

        // On trie les joueurs par ordre décroissant du coefficient
        ArrayList<Joueur> joueursTries = new ArrayList<>(joueurs.keySet());
        joueursTries.sort((j1, j2) -> {
            double coef1 = (double) joueurs.get(j1).get("coefficient");
            double coef2 = (double) joueurs.get(j2).get("coefficient");
            return Double.compare(coef2, coef1);
        });

        System.out.println("Statistiques des joueurs de l'équipe " + idEquipe + " :");
        for (Joueur joueur : joueursTries) {
            HashMap<String, Number> stats = joueurs.get(joueur);
            System.out.println("\t" + joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom() + " :");
            System.out.println("\t\tTemps de jeu : " + stats.get("tempsDeJeu"));
            System.out.println("\t\tNombre d'essais marqués : " + stats.get("nbEssaisMarques"));
            System.out.println("\t\tNombre de points marqués : " + stats.get("ptsMarques"));
            System.out.println("\t\tCoefficient d'efficacité : " + stats.get("coefficient"));
        }
    }

    /**
     * Rechercher tous les matchs qui se sont déroulés à une date D et
     * dans lesquels le score d'une des équipes a dépassé un nombre P de points.
     *
     * @param collection collections de collection
     * @param dateString date du match au format "yyyy-MM-dd"
     * @param nbPtsMini  nombre de points minimum
     */
    public static void questionB(MongoCollection<Match> collection, String dateString, int nbPtsMini) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'00:00:00");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = sdf.parse(dateString + "T00:00:00.00");
        Bson bsonQuery = and(eq("date", date), or(gt("ptsD", nbPtsMini), gt("ptsE", nbPtsMini)));
        FindIterable<Match> matches = collection.find(bsonQuery);

        SimpleDateFormat sdfSortie = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println("Matchs du " + sdf.format(date) + " avec au moins " + nbPtsMini + " points marqués par une équipe");
        for (Match match : matches) {
            System.out.println("Match n°" + match.getIdMatch() + " :");
            System.out.println("\t Equipe Domicile : " + match.getEquipeD().getPays() + " -> " + match.getPtsD());
            System.out.println("\t Equipe Exterieure : " + match.getEquipeE().getPays() + " -> " + match.getPtsE());
        }
    }

    /**
     * Rechercher les équipes qui recevaient et qui ont été arbitrés par un arbitre A.
     *
     * @param collection collection de matchs
     * @param idArbitre  id de l'arbitre
     */
    public static void questionC(MongoCollection<Match> collection, String idArbitre) {
        FindIterable<Match> matchsFromArbitre = collection.find(eq("arbitre.idArbitre", idArbitre));

        // Dans le cas où l'arbitre n'existe pas, on affiche la liste de tous les arbitres disponibles
        if (matchsFromArbitre.first() == null) {
            System.out.println("Aucun collection trouvé pour l'arbitre " + idArbitre);
            System.out.println("Les arbitres disponibles sont : ");
            ArrayList<Arbitre> arbitres = new ArrayList<>();
            FindIterable<Match> allMatches = collection.find();
            for (Match m : allMatches) {
                Arbitre arbitre = m.getArbitre();
                if (!arbitres.contains(arbitre)) {
                    arbitres.add(arbitre);
                }
            }
            arbitres.sort(Comparator.comparing(Arbitre::getIdArbitre));
            for (Arbitre arbitre : arbitres) {
                System.out.println(arbitre.getIdArbitre() + " " + arbitre.getNom() + " " + arbitre.getPrenom());
            }
            return;
        }

        //Donc l'arbitre existe, on parcourt ses matchs pour afficher le nom de l'équipe domicile
        Arbitre arbitre = matchsFromArbitre.first().getArbitre();
        System.out.println("L'arbitre " + arbitre.getIdArbitre() + " " + arbitre.getNom() + " " + arbitre.getPrenom() + " a arbitré les équipes qui jouaient à domicile suivantes : ");
        for (Match m : matchsFromArbitre) {
            System.out.println("\tMatch n°" + m.getIdMatch() + " -> " + m.getEquipeD().getPays());
        }
    }

    /**
     * Rechercher tous les joueurs de l'équipe E1 qui ont débuté le match à la date D contre l’équipe E2.
     * Si aucun match n'est trouvé, on affiche un message d'erreur.
     *
     * @param collection collection de matchs
     * @param idEquipeD  id de l'équipe domicile
     * @param idEquipeE  id de l'équipe extérieure
     * @param dateString date du match au format "yyyy-MM-dd"
     */
    public static void questionD(MongoCollection<Match> collection, String idEquipeD, String idEquipeE, String dateString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'00:00:00");
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = sdf.parse(dateString + "T00:00:00.00");

            Bson query = and(eq("equipeD.idEquipe", idEquipeD), eq("equipeE.idEquipe", idEquipeE), eq("date", date));
            Match matchPrecis = collection.find(query).first();

            if (matchPrecis == null) {
                SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
                System.out.println("Aucun match trouvé pour l'équipe " + idEquipeD + " contre l'équipe " + idEquipeE + " à la date " + sdf2.format(date));
                return;
            }

            System.out.println("Match correspondant : " + matchPrecis.getIdMatch());
            System.out.println("Joueurs de l'équipe " + idEquipeD + " ayant débuté le match : ");
            for (Joueur joueur : matchPrecis.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipeD) && joueur.isTitulaire()) {
                    System.out.println("\t" + joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom());
                }
            }
        } catch (ParseException e) {
            System.out.println("Erreur de parsing de la date");
        }

    }

    /**
     * Afficher les joueurs de l'équipe E qui sont entrés en cours de jeu.
     *
     * @param collection collection de matchs
     * @param idEquipe   id de l'équipe
     */
    public static void questionE(MongoCollection<Match> collection, String idEquipe) {
        Bson query = or(eq("equipeD.idEquipe", idEquipe), eq("equipeE.idEquipe", idEquipe));
        FindIterable<Match> matches = collection.find(query);

        ArrayList<Joueur> joueursEntresEnCours = new ArrayList<>();
        System.out.println("Joueurs de l'équipe " + idEquipe + " entrés en cours de jeu au moins une fois : ");
        for (Match match : matches) {
            for (Joueur joueur : match.getJoueurs()) {
                if (!joueursEntresEnCours.contains(joueur) && joueur.getIdEquipe().equals(idEquipe) && !joueur.isTitulaire()) {
                    joueursEntresEnCours.add(joueur);
                    System.out.println("\t" + joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom());
                }
            }
        }
    }

    /**
     * Donner pour chaque joueur de l'équipe E le nombre de matchs qu'il a joué,
     * ainsi que le nombre de points et le nombre d'essais marqués.
     *
     * @param collection collection de matchs
     * @param idEquipe   id de l'équipe
     */
    public static void questionF(MongoCollection<Match> collection, String idEquipe) {
        HashMap<Joueur, HashMap<String, Integer>> statsJoueurs = new HashMap<>();
        Bson query = or(eq("equipeD.idEquipe", idEquipe), eq("equipeE.idEquipe", idEquipe));
        FindIterable<Match> matches = collection.find(query);

        for (Match match : matches) {
            for (Joueur joueur : match.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipe)) {
                    HashMap<String, Integer> stats;
                    if (!statsJoueurs.containsKey(joueur)) {
                        stats = new HashMap<>();
                        stats.put("nbMatchs", 1);
                        stats.put("nbEssais", joueur.getNbEssaisMarques());
                        stats.put("nbPts", joueur.getPtsMarques());
                    } else {
                        stats = statsJoueurs.get(joueur);
                        stats.put("nbMatchs", stats.get("nbMatchs") + 1);
                        stats.put("nbEssais", stats.get("nbEssais") + joueur.getNbEssaisMarques());
                        stats.put("nbPts", stats.get("nbPts") + joueur.getPtsMarques());
                    }
                    statsJoueurs.put(joueur, stats);
                }
            }
        }

        for (Joueur joueur : statsJoueurs.keySet()) {
            HashMap<String, Integer> stats = statsJoueurs.get(joueur);
            System.out.println("\t" + joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom() + " :");
            System.out.println("\t\tNombre de matchs joués : " + stats.get("nbMatchs"));
            System.out.println("\t\tNombre d'essais marqués : " + stats.get("nbEssais"));
            System.out.println("\t\tNombre de points marqués : " + stats.get("nbPts"));
        }

    }

    /**
     * Afficher le nom des joueurs de l'équipe E1 qui ont joué à la fois contre les équipes E2 et E3.
     *
     * @param collection collection de matchs
     * @param idEquipe1  id de l'équipe 1
     * @param idEquipe2  id de l'équipe 2
     * @param idEquipe3  id de l'équipe 3
     */
    public static void questionG(MongoCollection<Match> collection, String idEquipe1, String idEquipe2, String idEquipe3) {

        FindIterable<Match> matchsEquipe1Equipe2 = collection.find(or(and(eq("equipeD.idEquipe", idEquipe1), eq("equipeE.idEquipe", idEquipe2)), and(eq("equipeD.idEquipe", idEquipe2), eq("equipeE.idEquipe", idEquipe1))));

        FindIterable<Match> matchsEquipe1Equipe3 = collection.find(or(and(eq("equipeD.idEquipe", idEquipe1), eq("equipeE.idEquipe", idEquipe3)), and(eq("equipeD.idEquipe", idEquipe3), eq("equipeE.idEquipe", idEquipe1))));

        ArrayList<Joueur> joueursEquipe1Equipe2 = new ArrayList<>();
        ArrayList<Joueur> joueursEquipe1Equipe3 = new ArrayList<>();

        for (Match matchEquipe1Equipe2 : matchsEquipe1Equipe2) {
            for (Joueur joueur : matchEquipe1Equipe2.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipe1)) {
                    joueursEquipe1Equipe2.add(joueur);
                }
            }
        }

        for (Match matchEquipe1Equipe3 : matchsEquipe1Equipe3) {
            for (Joueur joueur : matchEquipe1Equipe3.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipe1)) {
                    joueursEquipe1Equipe3.add(joueur);
                }
            }
        }

        ArrayList<Joueur> joueursEquipe1Equipe2Equipe3 = new ArrayList<>();
        for (Joueur joueurEquipe1Equipe2 : joueursEquipe1Equipe2) {
            if (joueursEquipe1Equipe3.contains(joueurEquipe1Equipe2) && !joueursEquipe1Equipe2Equipe3.contains(joueurEquipe1Equipe2)) {
                joueursEquipe1Equipe2Equipe3.add(joueurEquipe1Equipe2);
            }
        }

        System.out.println("Joueurs de l'équipe " + idEquipe1 + " ayant joué contre les équipes " + idEquipe2 + " et " + idEquipe3 + " :");
        for (Joueur joueur : joueursEquipe1Equipe2Equipe3) {
            System.out.println("\t" + joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom());
        }
    }

    /**
     * Afficher les joueurs de l'équipe E qui n'ont joué aucun match.
     *
     * @param collection collection de matchs
     * @param idEquipe   id de l'équipe
     */
    public static void questionH(MongoCollection<Match> collection, String idEquipe) {
        Bson query = or(eq("equipeD.idEquipe", idEquipe), eq("equipeE.idEquipe", idEquipe));
        FindIterable<Match> matches = collection.find(query);

        String[] listesNoms = getNameTeamList(idEquipe);

        ArrayList<Joueur> joueurs = new ArrayList<>();
        ArrayList<String> joueursString = new ArrayList<>(List.of(listesNoms));
        for (Match match : matches) {
            for (Joueur joueur : match.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipe) && !joueurs.contains(joueur)) {
                    joueurs.add(joueur);
                }
            }
        }

        for (Joueur joueur : joueurs) {
            if (joueur.getIdEquipe().equals(idEquipe)) {
                int index = joueursString.indexOf(joueur.getPrenom() + " " + joueur.getNom());
                if (index != -1) {
                    joueursString.set(index, null);
                }
            }
        }

        if (joueursString.stream().allMatch(Objects::isNull)) {
            System.out.println("Tous les joueurs de l'équipe " + idEquipe + " ont joué au moins un match");
            return;
        }

        System.out.println("Joueurs de l'équipe " + idEquipe + " n'ayant joué aucun match :");
        for (int i = 0; i < joueursString.size(); i++) {
            if (joueursString.get(i) != null) {
                System.out.println("\t" + idEquipe + "_" + i + " " + joueursString.get(i));
            }
        }
    }

    /**
     * Afficher tous les joueurs de l’équipe E qui ont joué tous les matchs de leur équipe.
     *
     * @param collection collection de matchs
     * @param idEquipe   id de l'équipe
     */
    public static void questionI(MongoCollection<Match> collection, String idEquipe) {
        Bson query = or(eq("equipeD.idEquipe", idEquipe), eq("equipeE.idEquipe", idEquipe));
        FindIterable<Match> matches = collection.find(query);

        int nbMatchs = 0;
        for (Match match : matches) {
            nbMatchs++;
        }

        HashMap<Joueur, Integer> joueurs = new HashMap<>();

        for (Match match : matches) {
            for (Joueur joueur : match.getJoueurs()) {
                if (joueur.getIdEquipe().equals(idEquipe)) {
                    if (!joueurs.containsKey(joueur)) {
                        joueurs.put(joueur, 1);
                    } else {
                        joueurs.put(joueur, joueurs.get(joueur) + 1);
                    }
                }
            }
        }

        System.out.println("Joueurs de l'équipe " + idEquipe + " ayant joué tous les matchs de leur équipe :");
        for (Joueur joueur : joueurs.keySet()) {
            if (joueurs.get(joueur) == nbMatchs) {
                System.out.println("\t" + joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom());
            }
        }
    }

    /**
     * Afficher quel est le joueur de la coupe du monde qui a marqué le plus d'essais,
     * et celui qui a marqué le plus de points.
     *
     * @param collection collection de matchs
     */
    public static void questionJ(MongoCollection<Match> collection) {
        FindIterable<Match> matches = collection.find();
        HashMap<Joueur, HashMap<String, Integer>> statsJoueurs = new HashMap<>();

        for (Match match : matches) {
            for (Joueur joueur : match.getJoueurs()) {
                HashMap<String, Integer> stats;
                if (!statsJoueurs.containsKey(joueur)) {
                    stats = new HashMap<>();
                    stats.put("nbEssais", joueur.getNbEssaisMarques());
                    stats.put("nbPts", joueur.getPtsMarques());
                } else {
                    stats = statsJoueurs.get(joueur);
                    stats.put("nbEssais", stats.get("nbEssais") + joueur.getNbEssaisMarques());
                    stats.put("nbPts", stats.get("nbPts") + joueur.getPtsMarques());
                }
                statsJoueurs.put(joueur, stats);
            }
        }

        Joueur joueurPlusEssais = null;
        Joueur joueurPlusPts = null;

        for (Joueur joueur : statsJoueurs.keySet()) {
            System.out.println(joueur.getIdJoueur() + " " + joueur.getNom() + " " + joueur.getPrenom() + " :");
            System.out.println("\tNombre d'essais marqués : " + statsJoueurs.get(joueur).get("nbEssais"));
            System.out.println("\tNombre de points marqués : " + statsJoueurs.get(joueur).get("nbPts"));
            if (joueurPlusEssais == null || statsJoueurs.get(joueur).get("nbEssais") > statsJoueurs.get(joueurPlusEssais).get("nbEssais")) {
                joueurPlusEssais = joueur;
            }
            if (joueurPlusPts == null || statsJoueurs.get(joueur).get("nbPts") > statsJoueurs.get(joueurPlusPts).get("nbPts")) {
                joueurPlusPts = joueur;
            }
        }

        System.out.println("Joueur ayant marqué le plus d'essais : " + joueurPlusEssais.getIdJoueur() + " " + joueurPlusEssais.getNom() + " " + joueurPlusEssais.getPrenom()
                + " : " + statsJoueurs.get(joueurPlusEssais).get("nbEssais") + " essais");
        System.out.println("Joueur ayant marqué le plus de points : " + joueurPlusPts.getIdJoueur() + " " + joueurPlusPts.getNom() + " " + joueurPlusPts.getPrenom()
                + " : " + statsJoueurs.get(joueurPlusPts).get("nbPts") + " points");
    }

    /**
     * Insérer un arbitre A pour un match M tout en vérifiant
     * que la nationalité de A n’appartient pas au même pays qu’une des deux équipes.
     * @param collection collection de matchs
     */
    public static void questionK(MongoCollection<Match> collection, Arbitre arbitre, Match match){
        if(arbitre.getNationalite().equals(match.getEquipeD().getPays()) || arbitre.getNationalite().equals(match.getEquipeE().getPays())){
            System.out.println("Le pays de l'arbitre est " + arbitre.getNationalite() + " et ne peut pas arbitrer le match " + match.getIdMatch() + " car il y a une équipe de même nationalité");
            return;
        }
        System.out.println("L'arbitre " + arbitre.getIdArbitre() + " " + arbitre.getNom() + " " + arbitre.getPrenom() + " a été ajouté au match " + match.getIdMatch());
        collection.updateOne(eq("idMatch", match.getIdMatch()), set("arbitre", arbitre));
    }

    private static String[] getNameTeamList(String idEquipe) {
        return switch (idEquipe) {
            case "FRA" -> Constantes.JOUEURS_FRA;
            case "ENG" -> Constantes.JOUEURS_ENG;
            case "SCO" -> Constantes.JOUEURS_ECO;
            case "IRL" -> Constantes.JOUEURS_IRL;
            case "WAL" -> Constantes.JOUEURS_WAL;
            case "ITA" -> Constantes.JOUEURS_ITA;
            case "RSA" -> Constantes.JOUEURS_RSA;
            case "ARG" -> Constantes.JOUEURS_ARG;
            case "AUS" -> Constantes.JOUEURS_AUS;
            case "NZL" -> Constantes.JOUEURS_NZL;
            default -> throw new IllegalStateException("Unexpected value: " + idEquipe);
        };
    }
}

