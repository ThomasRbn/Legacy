package entity;

public class Equipe {
    private String idEquipe;
    private String pays;
    private String couleur;
    private String entraineur;

    public String getIdEquipe() {
        return idEquipe;
    }

    public Equipe setIdEquipe(String idEquipe) {
        this.idEquipe = idEquipe;
        return this;
    }

    public String getPays() {
        return pays;
    }

    public Equipe setPays(String pays) {
        this.pays = pays;
        return this;
    }

    public String getCouleur() {
        return couleur;
    }

    public Equipe setCouleur(String couleur) {
        this.couleur = couleur;
        return this;
    }

    public String getEntraineur() {
        return entraineur;
    }

    public Equipe setEntraineur(String entraineur) {
        this.entraineur = entraineur;
        return this;
    }

    @Override
    public String toString() {
        return "Equipe{\n" +
                "\t\tidEquipe : " + idEquipe + "\n" +
                "\t\tPays : " + pays + "\n" +
                "\t\tCouleur : " + couleur + "\n" +
                "\t\tEntraineur : " + entraineur + "\n" +
                "\t}";
    }
}
