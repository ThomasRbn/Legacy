package entity;

public class Stade {
    private String idStade;
    private String nom;
    private String ville;
    private int capacite;

    public String getIdStade() {
        return idStade;
    }

    public Stade setIdStade(String idStade) {
        this.idStade = idStade;
        return this;
    }

    public String getNom() {
        return nom;
    }

    public Stade setNom(String nom) {
        this.nom = nom;
        return this;
    }

    public String getVille() {
        return ville;
    }

    public Stade setVille(String ville) {
        this.ville = ville;
        return this;
    }

    public int getCapacite() {
        return capacite;
    }

    public Stade setCapacite(int capacite) {
        this.capacite = capacite;
        return this;
    }

    @Override
    public String toString() {
        return "Stade{\n" +
                "\t\tidStade : " + idStade + "\n" +
                "\t\tnom : " + nom + "\n" +
                "\t\tville : " + ville + "\n" +
                "\t\tcapacite : " + capacite +"\n" +
                "\t}";
    }
}
