package entity;

public class Poste {
    private String idPoste;
    private String libelle;

    public String getIdPoste() {
        return idPoste;
    }

    public Poste setIdPoste(String idPoste) {
        this.idPoste = idPoste;
        return this;
    }

    public String getLibelle() {
        return libelle;
    }

    public Poste setLibelle(String libelle) {
        this.libelle = libelle;
        return this;
    }

    @Override
    public String toString() {
        return "Poste{\n" +
                "\t\t\t\tidPoste : " + idPoste + "\n" +
                "\t\t\t\tlibelle : " + libelle + "\n" +
                "\t\t\t}\n";
    }
}
