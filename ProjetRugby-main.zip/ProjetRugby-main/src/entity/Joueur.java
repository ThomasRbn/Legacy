package entity;

import java.util.Objects;

public class Joueur {
    private String idJoueur;
    private String idEquipe;
    private String nom;
    private String prenom;
    private Poste poste;
    private boolean titulaire;
    private int tempsJeu;
    private int ptsMarques;
    private int nbEssaisMarques;
    private double coefficientEfficacite;

    public String getIdJoueur() {
        return idJoueur;
    }

    public Joueur setIdJoueur(String idJoueur) {
        this.idJoueur = idJoueur;
        return this;
    }

    public String getIdEquipe() {
        return idEquipe;
    }

    public Joueur setIdEquipe(String idEquipe) {
        this.idEquipe = idEquipe;
        return this;
    }

    public String getNom() {
        return nom;
    }

    public Joueur setNom(String nom) {
        this.nom = nom;
        return this;
    }

    public String getPrenom() {
        return prenom;
    }

    public Joueur setPrenom(String prenom) {
        this.prenom = prenom;
        return this;
    }

    public Poste getPoste() {
        return poste;
    }

    public Joueur setPoste(Poste poste) {
        this.poste = poste;
        return this;
    }

    public boolean isTitulaire() {
        return titulaire;
    }

    public Joueur setTitulaire(boolean titulaire) {
        this.titulaire = titulaire;
        return this;
    }

    public int getTempsJeu() {
        return tempsJeu;
    }

    public Joueur setTempsJeu(int tempsJeu) {
        this.tempsJeu = tempsJeu;
        return this;
    }

    public int getPtsMarques() {
        return ptsMarques;
    }

    public Joueur setPtsMarques(int ptsMarques) {
        this.ptsMarques = ptsMarques;
        return this;
    }

    public int getNbEssaisMarques() {
        return nbEssaisMarques;
    }

    public Joueur setNbEssaisMarques(int nbEssaisMarques) {
        this.nbEssaisMarques = nbEssaisMarques;
        return this;
    }

    public double getCoefficientEfficacite() {
        return coefficientEfficacite;
    }

    public Joueur setCoefficientEfficacite(double coefficientEfficacite) {
        this.coefficientEfficacite = coefficientEfficacite;
        return this;
    }

    @Override
    public String toString() {
        return "\t\tJoueur{\n" +
                "\t\t\tidJoueur : " + idJoueur + "\n" +
                "\t\t\tidEquipe : " + idEquipe + "\n" +
                "\t\t\tnom : " + nom + "\n" +
                "\t\t\tprenom : " + prenom + "\n" +
                "\t\t\tposte : " + poste  +
                "\t\t\ttitulaire : " + titulaire + "\n" +
                "\t\t\ttempsJeu : " + tempsJeu + "\n" +
                "\t\t\tptsMarques : " + ptsMarques + "\n" +
                "\t\t\tnbEssaisMarques : " + nbEssaisMarques + "\n" +
                "\t\t}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Joueur joueur = (Joueur) o;
        return Objects.equals(idJoueur, joueur.idJoueur);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idJoueur);
    }
}
