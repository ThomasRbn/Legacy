package entity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Match {

    private int idMatch;
    private Equipe equipeD;
    private Equipe equipeE;
    private Date date;
    private Stade stade;
    private int nbSpecs;
    private int ptsD;
    private int essaisD;
    private int ptsE;
    private int essaisE;
    private Arbitre arbitre;
    private ArrayList<Joueur> joueurs;

    public int getIdMatch() {
        return idMatch;
    }

    public Match setIdMatch(int idMatch) {
        this.idMatch = idMatch;
        return this;
    }

    public Equipe getEquipeD() {
        return equipeD;
    }

    public Match setEquipeD(Equipe equipeD) {
        this.equipeD = equipeD;
        return this;
    }

    public Equipe getEquipeE() {
        return equipeE;
    }

    public Match setEquipeE(Equipe equipeE) {
        this.equipeE = equipeE;
        return this;
    }

    public Date getDate() {
        return date;
    }

    public Match setDate(Date date) {
        this.date = date;
        return this;
    }

    public Stade getStade() {
        return stade;
    }

    public int getNbSpecs() {
        return nbSpecs;
    }

    public Match setNbSpecs(int nbSpecs) {
        this.nbSpecs = nbSpecs;
        return this;
    }

    public Match setStade(Stade stade) {
        this.stade = stade;
        return this;
    }

    public int getPtsD() {
        return ptsD;
    }

    public Match setPtsD(int ptsD) {
        this.ptsD = ptsD;
        return this;
    }

    public int getEssaisD() {
        return essaisD;
    }

    public Match setEssaisD(int essaisD) {
        this.essaisD = essaisD;
        return this;
    }

    public int getPtsE() {
        return ptsE;
    }

    public Match setPtsE(int ptsE) {
        this.ptsE = ptsE;
        return this;
    }

    public int getEssaisE() {
        return essaisE;
    }

    public Match setEssaisE(int essaisE) {
        this.essaisE = essaisE;
        return this;
    }

    public Arbitre getArbitre() {
        return arbitre;
    }

    public Match setArbitre(Arbitre arbitre) {
        this.arbitre = arbitre;
        return this;
    }

    public ArrayList<Joueur> getJoueurs() {
        return joueurs;
    }

    public Match setJoueurs(ArrayList<Joueur> joueurs) {
        this.joueurs = joueurs;
        return this;
    }

    @Override
    public String toString() {
        String joueursString = "";
        for (Joueur joueur : joueurs) {
            joueursString += joueur + "\n";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return "Match{\n" +
                "\tidMatch : " + idMatch + "\n" +
                "\tequipeD : " + equipeD + "\n" +
                "\tequipeE : " + equipeE + "\n" +
                "\tdate : " + sdf.format(date)+ "\n" +
                "\tstade : " + stade + "\n" +
                "\tptsD : " + ptsD + "\n" +
                "\tessaisD : " + essaisD + "\n" +
                "\tptsE : " + ptsE + "\n" +
                "\tessaisE : " + essaisE + "\n" +
                "\tarbitre : " + arbitre + "\n" +
                "\tjoueurs : [\n" + joueursString + "\t]\n" +
                "}";
    }
}
