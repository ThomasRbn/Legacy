package entity;

import java.util.Objects;

public class Arbitre {
    private String idArbitre;
    private String nom;
    private String prenom;
    private String nationalite;

    public String getIdArbitre() {
        return idArbitre;
    }

    public Arbitre setIdArbitre(String idArbitre) {
        this.idArbitre = idArbitre;
        return this;
    }

    public String getNom() {
        return nom;
    }

    public Arbitre setNom(String nom) {
        this.nom = nom;
        return this;
    }

    public String getPrenom() {
        return prenom;
    }

    public Arbitre setPrenom(String prenom) {
        this.prenom = prenom;
        return this;
    }

    public String getNationalite() {
        return nationalite;
    }

    public Arbitre setNationalite(String nationalite) {
        this.nationalite = nationalite;
        return this;
    }

    @Override
    public String toString() {
        return "Arbitre{\n" +
                "\t\tidArbitre : " + idArbitre + "\n" +
                "\t\tnom : " + nom + "\n" +
                "\t\tprenom : " + prenom + "\n" +
                "\t\tnationalite : " + nationalite + "\n" +
                "\t}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Arbitre arbitre = (Arbitre) o;
        return Objects.equals(idArbitre, arbitre.idArbitre) && Objects.equals(nom, arbitre.nom) && Objects.equals(prenom, arbitre.prenom) && Objects.equals(nationalite, arbitre.nationalite);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idArbitre, nom, prenom, nationalite);
    }
}
