/**
 * Contient les classes specifiques à la résolution de problèmes
 */

package rushhour.ia.framework.recherche;
