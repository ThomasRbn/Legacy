/**
 * Contient les classes des problèmes
 */

package rushhour.ia.problemes;
