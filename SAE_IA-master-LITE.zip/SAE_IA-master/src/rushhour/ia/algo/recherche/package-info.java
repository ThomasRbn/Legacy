/**
 * Contient les classes des algorithmes de recherche
 */

package rushhour.ia.algo.recherche;
