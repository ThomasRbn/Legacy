# SAE Système : Création d'une application mBash

## Prérequis

## Commandes utilisables dans l'application
- `ls` : Avec toutes ses options, depuis et vers tous les répertoires. <br>
<t>Exemple : `ls -l /etc`, `ls /home -al`, `ls`, `ls ../`, ...</t>
- `cd` : Vers tous les répertoires (y compris vers les chemins absolus et le home) <br>
<t>Exemple : `cd /etc`, `cd ..`, `cd`, ...</t>
- `echo` : Messages passés en arguments et les variables d'environnement (seulement les principales, comme $HOME, $USER, ...)<br>
<t>Exemple : `echo "Hello World"`, `echo $PATH`, `echo $USER`, ...</t><br>
On peut aussi afficher le PID de mBash avec `echo $$`<br>
<t><i>En revanche `echo $PS1` ne fonctionnera pas, car la variable n'est pas exportée.</i></t>
- `history` : Affiche l'historique des 100 dernières commandes tapées dans l'application. <br>
- `pwd`
- Comment quitter l'application ? <b> Un simple CTRL + C </b> suffit ! <br>
- Il est possible de lancer les applications en arrière plan en ajoutant le &